package praktikum3;

public class PerulanganFOR {
	public static void main(String[]args) {
		for(int angka = 4; angka<= 10; angka++) {
			System.out.println("Angka ke- " +angka);
		}
	}
}
