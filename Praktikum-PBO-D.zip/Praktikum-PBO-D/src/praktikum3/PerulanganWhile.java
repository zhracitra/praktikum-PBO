package praktikum3;

public class PerulanganWhile {
	public static void main(String[]args) {
		int angka = 8;
		while(angka<=10) {
			System.out.println("Angka ke-"+angka);
			angka++;
		}
	}
}
