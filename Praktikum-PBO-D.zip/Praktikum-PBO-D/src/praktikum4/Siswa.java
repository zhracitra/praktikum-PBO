package praktikum4;

public class Siswa {
	int npm;
	String nama;
	
	public void setNpm(int i) {
		npm = i;
	}
	
	public void setNama(String i) {
		nama = i;
	}
	
	public int getNpm() {
		return npm;
	}
}
